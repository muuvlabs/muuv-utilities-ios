//
//
//  WorkoutsPlayerUI.h
//
//  Created by Cristian Barril on 09/01/2023
//
//

#import <Foundation/Foundation.h>

//! Project version number for WorkoutsPlayerUI.
FOUNDATION_EXPORT double WorkoutsPlayerUIVersionNumber;

//! Project version string for WorkoutsPlayerUI.
FOUNDATION_EXPORT const unsigned char WorkoutsPlayerUIVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WorkoutsPlayerUI/PublicHeader.h>


