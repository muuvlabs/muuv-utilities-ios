//
//
//  WorkoutsPlayerCoreInternal.h
//
//  Created by Cristian Barril on 24/01/2023
//
//

#import <Foundation/Foundation.h>

//! Project version number for WorkoutsPlayerCoreInternal.
FOUNDATION_EXPORT double WorkoutsPlayerCoreInternalVersionNumber;

//! Project version string for WorkoutsPlayerCoreInternal.
FOUNDATION_EXPORT const unsigned char WorkoutsPlayerCoreInternalVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WorkoutsPlayerCoreInternal/PublicHeader.h>


